#ifndef EVENTCOMPONENT_H
#define EVENTCOMPONENT_H

#include <iostream>
#include <vector>
#include <string>

#include "Observer.h"
#include "Subject.h"
#include "Notification.h"
#include "Status.h"
#include "Cascade.h"
#include "EventControl.h"

/**
 * @class EventComponent
 * @brief interface describing the behaviour of leaves and composites for the EventFlow System
 * inherits from observer class and observes EventControl in Observer Pattern
 * @note GoF Design Pattern, Participation -> Component
 */
class EventComponent : public Observer
{
public:
	virtual ~EventComponent();

	/**
	 * @brief Constructor: create instance of of event class.
	 * note that you cannot instantiate object of abstract class
	 * @param name identifier name for given EventComponent
	 * @param subject Event control to be observed 
	 */
	EventComponent(std::string name);

	/**
	 * @brief add EventComponent to children vector in EventGroup for composite event type
	 * - Does nothing for leaf EventComponent because it does not contain a vector of EventComponent
	 * @param child EventComponent to be added to vector of event components for EventGroup
	 */
	virtual void add(EventComponent *child) {}

	/**
	 * @brief remove target EventComponent from children list
	 * - does nothing for leaf components
	 * @param target the child to be removed from the children list
	 * @return void
	 */
	virtual void remove(EventComponent *target) {}

	// inherited from observer superclass
	virtual void update();

	/**
	 * @brief print information for EventComponent
	 * @param indent Level of indention for nested components
	 * @return void
	 */
	virtual void display(std::string indent = "");

	/**
	 * @brief return name of EventComponent
	 * @return string
	 */
	std::string getName();

	/**
	 * @brief return vector of children EventComponents
	 * @return vector<EventComponent*>
	 */
	virtual std::vector<EventComponent *> getChildren() { return {}; }

	/**
	 * @brief update EventComponent name
	 * @param name new name
	 * @return void
	 */
	void setName(std::string name);

	/**
	 * @brief return status of EventComponent
	 * @return Status EventComponent status
	 */
	Status *getStatus();

	/**
	 * @brief set status to new passed in status
	 * - sets status based on the notification passed in
	 * @param status new status
	 * @return void
	 */
	void setStatus(Status *status);

	/**
	 * @brief Determine the appropriate next state base on notification
	 * - always returns Cascade for EventGroup since it's status is a combination of the childrens status
	 * @param notification Notification from subject
	 * @return Status* new status
	 */
	virtual Status *determineStatus(Notification Notification);

	/**
	 * @brief set Subject to passed in subject parameter
	 * @param subject new subject
	 * @return void
	 */
	virtual void setSubject(EventControl *subject);
	
	void detach();

protected:
	/**
	 * @brief subject being observed
	 */
	EventControl *subject;
	std::string name;
	Notification notification;
	int capacity;
	int occupancy;
	Status *status;

private:
	EventComponent();
};

#endif
